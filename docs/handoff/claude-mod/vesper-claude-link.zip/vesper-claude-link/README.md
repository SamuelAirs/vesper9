# VESPER-9 Claude link (vesper-link mod)

A Claude Code mod that turns Claude Code into a VESPER-9 field console whenever the Vesper node
is plugged in. It does not use or talk to the Vesper console software: it reaches the node
through its own small bridge program.

## What you get

| When | On screen | On the node's lamps |
| --- | --- | --- |
| Node plugged in, nothing happening | A VESPER-9 instrument band above the prompt (lamps, state, temperature and humidity) | A dim green breath on the middle lamp |
| Claude is working | `CLAUDE AT WORK`, spinner words like "Calculating orbit" | A green light sweeping left and right |
| Claude runs a tool | `FIELD OPERATION` | The right lamp ticks cyan |
| Claude needs a permission decision | `DECISION REQUIRED` | Outer lamps alternate amber and red |
| Claude has answered, your turn | `AWAITING OPERATOR` | All three breathe amber (dims to standby after 10 minutes) |
| You hold the button | `TRANSMITTING ▮▮▮▯▯`, your words appear live | Left two lamps meter your voice in amber, right lamp steady blue (mic live) |
| You let go | `DECODING SIGNAL`, then your words are sent as your reply | A fast cyan sweep, then a green blink (or red if nothing was heard) |
| You tap twice while Claude works | The turn is stopped | A red blink |

Your messages show as `▸ OPERATOR · VOICE CH-1` (or `KEY CH-2` when typed) and Claude's as
`◂ CLAUDE · INCOMING`, in the console's palette. `/vesper` opens a console pane with every channel
of the link. Unplug the node and Claude Code looks normal again.

## Controls

- Hold the node's button (longer than a quarter second), speak, let go: your reply is sent.
  Setting `voiceSend: draft` puts it in the prompt box instead, for you to check.
- Two quick taps: stop Claude's current turn (setting `doubleTapInterrupt`).
- `/vesper`: the console pane. `/vesper takeover` and `/vesper release`: borrow the node from
  the Vesper console on the Pi and give it back. `/vesper lamps 0-100`: lamp brightness.
- `/vesper simulate` and `/vesper say <text>`: try everything without a node.

## How it fits together

```
node ──USB serial (protocol v1)── bridge (Python, ~/.local/share/vesper-claude-link)
                                     │ stdout: JSON lines (node, button, speech, sensors)
                                     │ HTTP 127.0.0.1:47219 with a per-session token (lamp mode)
                                  vesper-link mod (~/.claude/mods/vesper-link) ── Claude Code
```

- The mod starts the bridge with each Claude Code session and stops it when the session ends.
  The bridge also quits if the mod goes quiet for 30 seconds, and always leaves the lamps and the
  microphone off.
- The microphone is on only while the button is held (60 seconds at most). Speech is recognised
  on the machine with Vosk, plus the console's Parakeet second pass when it is installed. Audio is
  kept in memory only until the words are out, and nothing goes to the cloud except the text you
  send to Claude.
- On the Pi the Vesper console service normally holds the node. The bridge never fights it: it
  says the node is held, and `/vesper takeover` stops the console service and restarts it on
  `/vesper release` or when the session ends. Setting `handoff` in `config.json` to `auto` does
  that without asking.
- Node firmware is unchanged (0.1.x, protocol v1). Nothing needs flashing.

## Install

Hand `INSTALL-PROMPT.md` to Claude Code on the Pi or the desktop, or run `bash install.sh`
(`--vesper-dir PATH` on the Pi). Settings for the mod are in `/config` under vesper-link; the
bridge's are in `~/.local/share/vesper-claude-link/config.json`.

## Status

Built and checked off-device: the bridge's tests drive it through a fake node on a
pseudo-terminal (connect, push-to-talk, tap, mic muting, disconnect), the mod validates,
type-checks and passes its tests, and a headless Claude Code 2.1.287 session loaded it,
started the bridge and ran `/vesper simulate`. It has not been run with the real node,
real speech or on the Pi's screen yet.
