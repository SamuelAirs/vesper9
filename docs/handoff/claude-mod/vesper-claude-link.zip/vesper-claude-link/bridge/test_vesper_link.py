"""Tests for the node bridge. A pseudo-terminal stands in for the node, speaking protocol v1, so
the whole push-to-talk path runs without hardware. Run: python3 -m unittest test_vesper_link.py
(needs pyserial; Linux or macOS for the pseudo-terminal)."""
import json
import os
import struct
import threading
import time
import types
import unittest

import vesper_link as vl


class Protocol(unittest.TestCase):
    def test_crc_vector(self):
        self.assertEqual(vl.crc16(b"123456789"), 0x29B1)

    def test_decoder_survives_noise_and_splits(self):
        frame = vl.encode(vl.BUTTON, struct.pack("<QB", 5, 1), 7)
        d = vl.Decoder()
        self.assertEqual(d.feed(b"boot noise V" + frame[:5]), [])
        self.assertEqual(d.feed(frame[5:]), [(vl.BUTTON, struct.pack("<QB", 5, 1))])
        bad = bytearray(frame)
        bad[-1] ^= 0xFF
        self.assertEqual(d.feed(bytes(bad) + frame), [(vl.BUTTON, struct.pack("<QB", 5, 1))])
        self.assertEqual(d.errors, 1)


class Lamps(unittest.TestCase):
    def test_every_mode_is_nine_bytes(self):
        for mode in ("off", "idle", "working", "tool", "waiting", "attention", "listening", "transcribing", "error", "ack"):
            for t in (0, 0.3, 1.1, 2.9):
                values = vl.lamp_frame(mode, t, 0.5, 0.5)
                self.assertEqual(len(values), 9, mode)
                self.assertTrue(all(0 <= v <= 255 for v in values), mode)

    def test_off_is_dark(self):
        self.assertEqual(vl.lamp_frame("off", 1.0), [0] * 9)

    def test_mic_lamp_visible_at_zero_brightness(self):
        values = vl.lamp_frame("listening", 0, 0.0, 0.0)
        self.assertEqual(values[:6], [0] * 6)
        self.assertGreater(values[8], 0)  # right lamp blue stays lit: the privacy signal


class FakeRecognizer:
    def __init__(self):
        self.n = 0

    def AcceptWaveform(self, pcm):
        self.n += 1
        return False

    def PartialResult(self):
        return json.dumps({"partial": "hello"})

    def Result(self):
        return json.dumps({"text": ""})

    def FinalResult(self):
        return json.dumps({"text": "hello vesper"})


class FakeSpeech:
    state, detail, refiner = "ready", None, None

    def session(self):
        return FakeRecognizer()


class NodeOverPty(unittest.TestCase):
    """The bridge against a fake node on a pseudo-terminal."""

    def setUp(self):
        try:
            import serial  # noqa: F401
        except ImportError:
            self.skipTest("pyserial not installed")
        self.events = []
        self.original_emit = vl.emit
        vl.emit = lambda kind, **f: self.events.append({"type": kind, **f})
        self.master, slave = os.openpty()
        import tty
        tty.setraw(self.master)
        tty.setraw(slave)
        self.path = os.ttyname(slave)
        args = types.SimpleNamespace(port=self.path, vosk_model="", refine_model="", console_service="",
                                     handoff="never", brightness=0.5, http_port=0, standalone=True)
        self.link = vl.Link(args)
        self.link.speech = FakeSpeech()
        self.received = []
        self.stop = threading.Event()
        threading.Thread(target=self.node_reader, daemon=True).start()
        self.thread = threading.Thread(target=self.link.run_port, args=(self.path,), daemon=True)
        self.thread.start()
        threading.Thread(target=self.link.speech_worker, daemon=True).start()
        # opening the port flushes its input; the real node repeats STATUS every second, the
        # fake one speaks once, so wait until the bridge has the port open (its first PING)
        self.assertTrue(self.wait_for(lambda: self.sent(vl.PING)))

    def tearDown(self):
        if not hasattr(self, "link"):
            return
        self.link.stop.set()
        self.stop.set()
        self.thread.join(2)
        vl.emit = self.original_emit
        os.close(self.master)

    def node_reader(self):
        d = vl.Decoder()
        while not self.stop.is_set():
            try:
                data = os.read(self.master, 4096)
            except OSError:
                return
            self.received.extend(d.feed(data))

    def node_send(self, kind, payload):
        os.write(self.master, vl.encode(kind, payload))

    def wait_for(self, predicate, timeout=3.0):
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            if predicate():
                return True
            time.sleep(0.02)
        return False

    def sent(self, kind):
        return [p for k, p in self.received if k == kind]

    def test_connect_push_to_talk_and_disconnect(self):
        self.node_send(vl.HELLO, json.dumps({"fw": "0.1.2", "link": "uart", "mic": False}).encode())
        self.assertTrue(self.wait_for(lambda: any(e["type"] == "node" and e["connected"] for e in self.events)), self.events)
        # on connect the bridge mutes the mic and clears the lamps, as the console does
        self.assertTrue(self.wait_for(lambda: self.sent(vl.MIC) and self.sent(vl.LEDS)))
        self.assertEqual(self.sent(vl.MIC)[0], b"\x00")

        self.node_send(vl.BUTTON, struct.pack("<QB", 1000, 1))
        self.assertTrue(self.wait_for(lambda: b"\x01" in self.sent(vl.MIC)))  # mic on only while held
        for i in range(30):  # 0.6 s of a quiet tone
            pcm = struct.pack("<320h", *([1000, -1000] * 160))
            self.node_send(vl.AUDIO, struct.pack("<I", i * 320) + pcm)
            time.sleep(0.02)
        self.node_send(vl.BUTTON, struct.pack("<QB", 700000, 0))
        self.assertTrue(self.wait_for(lambda: any(e.get("state") == "done" for e in self.events)))
        done = [e for e in self.events if e.get("state") == "done"][0]
        self.assertEqual(done["text"], "hello vesper")
        self.assertEqual(self.sent(vl.MIC)[-1], b"\x00")  # mic off again after release

        # a short press is a tap, and the mic is switched off at once
        self.node_send(vl.BUTTON, struct.pack("<QB", 800000, 1))
        self.node_send(vl.BUTTON, struct.pack("<QB", 850000, 0))
        self.assertTrue(self.wait_for(lambda: any(e["type"] == "tap" for e in self.events)))
        self.assertEqual(self.sent(vl.MIC)[-1], b"\x00")

        # silence from the node: the bridge declares it gone after four seconds
        self.assertTrue(self.wait_for(lambda: any(e["type"] == "node" and not e["connected"] for e in self.events), 7))

    def test_stray_capture_is_muted(self):
        self.node_send(vl.STATUS, json.dumps({"fw": "0.1.2", "mic": True}).encode())
        self.assertTrue(self.wait_for(lambda: len(self.sent(vl.MIC)) >= 2))
        self.assertTrue(all(p == b"\x00" for p in self.sent(vl.MIC)))


if __name__ == "__main__":
    unittest.main()
