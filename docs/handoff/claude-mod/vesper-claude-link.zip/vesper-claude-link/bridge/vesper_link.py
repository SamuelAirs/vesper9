#!/usr/bin/env python3
"""VESPER-9 Claude link: the node bridge for the vesper-link Claude Code mod.

The mod cannot open a serial port itself, so it starts this program and talks to it:

  * stdout, one JSON object per line, bridge -> mod: the node's presence, button presses,
    push-to-talk state and the recognised text, microphone level, sensor readings.
  * HTTP on 127.0.0.1 (POST, JSON body, X-Link-Token header), mod -> bridge: the lamp mode
    (/mode), short lamp effects (/flash), borrowing the node from the Vesper console
    (/takeover, /release), a keep-alive (/alive) and a simulator for testing (/simulate).

The node speaks VESPER protocol v1 (docs/PROTOCOL.md in the vesper9 repo) and its firmware is
not changed. The microphone is on only while the button is held, the right lamp shows steady
blue whenever it is on (the console's own privacy signal), and audio never leaves this process
or touches the disk. Speech is recognised locally with Vosk, optionally refined by the same
Parakeet model the console uses.

It exits, with the lamps off, the microphone off and the console service restarted if it was
borrowed, when the mod stops talking to it for 30 seconds, when its parent dies, or on SIGTERM.
"""
import argparse
import contextlib
import json
import math
import os
import queue
import signal
import struct
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

VERSION = "0.1.0"

# ---- protocol v1 (same as vesper/protocol.py) ----------------------------------------------

MAGIC = b"V9"
PROTO = 1
MAX_PAYLOAD = 768
HEADER = struct.Struct("<2sBBHH")
HELLO, BUTTON, SENSOR, AUDIO, CUE, STATUS, ACK = 1, 2, 3, 4, 5, 6, 7
PING, LEDS, MIC, ARM, CANCEL, PATTERN = 16, 17, 18, 19, 20, 21

# USB ids of the node: the CH343 COM bridge (preferred, verified on Sam's board) and the
# ESP32-S3 native USB port.
NODE_IDS = {(0x1A86, 0x55D3), (0x303A, 0x1001)}


def crc16(data):
    crc = 0xFFFF
    for value in data:
        crc ^= value << 8
        for _ in range(8):
            crc = ((crc << 1) ^ (0x1021 if crc & 0x8000 else 0)) & 0xFFFF
    return crc


def encode(kind, payload=b"", sequence=0):
    frame = HEADER.pack(MAGIC, PROTO, kind, sequence & 0xFFFF, len(payload)) + payload
    return frame + struct.pack("<H", crc16(frame[2:]))


class Decoder:
    """Bounded streaming decoder: tolerates boot noise, partial reads and corrupt frames."""

    def __init__(self):
        self.buffer = bytearray()
        self.errors = 0

    def feed(self, data):
        self.buffer.extend(data)
        out = []
        while True:
            start = self.buffer.find(MAGIC)
            if start < 0:
                keep = self.buffer.endswith(MAGIC[:1])
                self.buffer[:] = self.buffer[-1:] if keep else b""
                return out
            del self.buffer[:start]
            if len(self.buffer) < HEADER.size:
                return out
            _, version, kind, _seq, length = HEADER.unpack_from(self.buffer)
            if version != PROTO or length > MAX_PAYLOAD:
                self.errors += 1
                del self.buffer[0]
                continue
            size = HEADER.size + length + 2
            if len(self.buffer) < size:
                return out
            if crc16(self.buffer[2:size - 2]) != struct.unpack_from("<H", self.buffer, size - 2)[0]:
                self.errors += 1
                del self.buffer[0]
                continue
            out.append((kind, bytes(self.buffer[8:size - 2])))
            del self.buffer[:size]


# ---- output to the mod ---------------------------------------------------------------------

_out_lock = threading.Lock()


def emit(kind, **fields):
    line = json.dumps({"type": kind, **fields}, separators=(",", ":"))
    with _out_lock:
        try:
            sys.stdout.write(line + "\n")
            sys.stdout.flush()
        except (BrokenPipeError, ValueError):
            os._exit(0)  # the mod is gone


# ---- lamps -----------------------------------------------------------------------------------

# The console's own lamp colours (web/engine/lightshow.js).
GREEN, AMBER, RED, CYAN, BLUE, WHITE = (30, 255, 70), (255, 110, 0), (255, 12, 0), (0, 200, 170), (0, 40, 255), (255, 200, 150)
OFF = (0, 0, 0)
MIC_FLOOR = 0.3  # the mic-live lamp never drops below this, whatever the lamp level


def dim(rgb, level):
    level = max(0.0, min(1.0, level))
    return tuple(round(c * level) for c in rgb)


def breathe(t, period, low=0.15, high=1.0):
    return low + (high - low) * (0.5 - 0.5 * math.cos(2 * math.pi * t / period))


def lamp_frame(mode, t, level=0.0, scale=0.5):
    """Nine values for a lamp mode at time t (seconds). `level` is the mic level 0..1 and
    `scale` the overall lamp brightness. Pure, so it is tested without a node."""
    if mode == "off":
        return [0] * 9
    if mode == "idle":  # a very dim phosphor breath on the middle lamp: linked, nothing going on
        lamps = [OFF, dim(GREEN, 0.12 * breathe(t, 4.0, 0.2)), OFF]
    elif mode == "working":  # a green spot sweeping left-right-left: Claude is working
        pos = 0.5 - 0.5 * math.cos(2 * math.pi * t / 1.6)
        lamps = [dim(GREEN, max(0.0, 1 - abs(pos * 2 - i) / 0.9)) for i in range(3)]
    elif mode == "tool":  # working, with the right lamp ticking cyan for a tool call
        pos = 0.5 - 0.5 * math.cos(2 * math.pi * t / 1.6)
        lamps = [dim(GREEN, max(0.0, 1 - abs(pos * 2 - i) / 0.9)) for i in range(2)] + [CYAN]
    elif mode == "waiting":  # all three breathing amber: your turn
        lamps = [dim(AMBER, breathe(t, 2.6, 0.12))] * 3
    elif mode == "attention":  # outer lamps alternating amber and red: Claude needs a decision
        on = int(t / 0.4) % 2 == 0
        lamps = [AMBER if on else RED, dim(AMBER, 0.2), RED if on else AMBER]
    elif mode == "listening":  # amber meter of your voice on the left two, mic-live blue on the right
        fill = max(0.0, min(1.0, level)) * 2
        lamps = [dim(AMBER, 0.15 + 0.85 * min(1.0, fill)), dim(AMBER, 0.15 + 0.85 * max(0.0, fill - 1)), BLUE]
    elif mode == "transcribing":  # a fast cyan sweep while the words are worked out
        pos = (t / 0.5) % 1.0
        lamps = [dim(CYAN, max(0.0, 1 - abs(pos * 2 - i) / 0.75)) for i in range(3)]
    elif mode == "error":
        lamps = [RED] * 3 if int(t / 0.15) % 2 == 0 else [OFF] * 3
    elif mode == "ack":
        lamps = [dim(GREEN, 0.8)] * 3
    else:
        lamps = [OFF] * 3
    values = []
    for i, rgb in enumerate(lamps):
        if mode == "listening" and i == 2:
            rgb = dim(rgb, max(MIC_FLOOR, scale))  # privacy signal: always visible
        else:
            rgb = dim(rgb, scale)
        values.extend(rgb)
    return values


# ---- speech ----------------------------------------------------------------------------------

class Speech:
    """Local recognition of one push-to-talk utterance at a time. Vosk is required for speech;
    the Parakeet second pass (sherpa-onnx) is used when installed, as in the console."""

    def __init__(self, vosk_path, refine_path):
        self.vosk_path = Path(vosk_path).expanduser() if vosk_path else None
        self.refine_path = Path(refine_path).expanduser() if refine_path else None
        self.model = self.refiner = None
        self.state, self.detail = "loading", None
        threading.Thread(target=self.load, daemon=True).start()

    def load(self):
        try:
            import vosk
            vosk.SetLogLevel(-1)
        except ImportError:
            self.state, self.detail = "unavailable", "pip install vosk"
            emit("speech", state=self.state, detail=self.detail)
            return
        if not self.vosk_path or not (self.vosk_path / "am").is_dir():
            self.state, self.detail = "unavailable", f"no Vosk model at {self.vosk_path}"
            emit("speech", state=self.state, detail=self.detail)
            return
        self.model = vosk.Model(str(self.vosk_path))
        engine = "vosk"
        files = ("encoder.int8.onnx", "decoder.int8.onnx", "joiner.int8.onnx", "tokens.txt")
        if self.refine_path and all((self.refine_path / f).is_file() for f in files):
            try:
                import sherpa_onnx  # noqa: F401
                import numpy  # noqa: F401
                d = self.refine_path
                self.refiner = sherpa_onnx.OfflineRecognizer.from_transducer(
                    encoder=str(d / files[0]), decoder=str(d / files[1]), joiner=str(d / files[2]),
                    tokens=str(d / files[3]), num_threads=2, model_type="nemo_transducer")
                engine = "vosk+parakeet"
            except Exception as exc:  # the second pass is optional
                self.detail = f"second pass off: {exc}"
        self.state = "ready"
        emit("speech", state="ready", engine=engine, detail=self.detail)

    def session(self):
        import vosk
        return vosk.KaldiRecognizer(self.model, 16000)

    def refine(self, pcm):
        import numpy as np
        samples = np.frombuffer(pcm, dtype=np.int16).astype(np.float32) / 32768.0
        stream = self.refiner.create_stream()
        stream.accept_waveform(16000, samples)
        self.refiner.decode_stream(stream)
        return stream.result.text.strip()


class Talk:
    """One push-to-talk utterance: audio is held in memory only until its text is final."""

    MAX_S = 60

    def __init__(self, speech):
        self.speech = speech
        self.rec = speech.session() if speech else None
        self.audio = bytearray()
        self.started = time.monotonic()
        self.partial = ""
        self.last_partial_at = 0.0
        self.level = 0.0
        self._committed = ""
        self.cancelled = False

    def feed(self, pcm):
        if len(self.audio) < self.MAX_S * 32000:
            self.audio.extend(pcm)
        n = len(pcm) // 2
        if n:
            samples = struct.unpack(f"<{n}h", pcm[:n * 2])
            rms = math.sqrt(sum(s * s for s in samples) / n) / 32768.0
            # -50 dBFS .. -10 dBFS mapped to 0..1, smoothed
            db = 20 * math.log10(max(rms, 1e-6))
            target = max(0.0, min(1.0, (db + 50) / 40))
            self.level = self.level * 0.6 + target * 0.4
        if self.rec is None:
            return None
        if self.rec.AcceptWaveform(bytes(pcm)):
            text = json.loads(self.rec.Result()).get("text", "")
            self.partial = (self.committed() + " " + text).strip()
            self._committed = self.partial
            return self.partial
        now = time.monotonic()
        if now - self.last_partial_at > 0.2:
            self.last_partial_at = now
            text = json.loads(self.rec.PartialResult()).get("partial", "")
            return (self.committed() + " " + text).strip()
        return None

    def committed(self):
        return self._committed

    def finish(self):
        text = self.committed()
        if self.rec is not None:
            tail = json.loads(self.rec.FinalResult()).get("text", "")
            text = (text + " " + tail).strip()
        engine = "vosk"
        if self.speech and self.speech.refiner is not None and len(self.audio) > 0.3 * 32000:
            try:
                refined = self.speech.refine(bytes(self.audio))
                if refined:
                    text, engine = refined, "parakeet"
            except Exception as exc:
                emit("log", message=f"second pass failed, using Vosk: {exc}")
        self.audio = bytearray()
        return text, engine


# ---- the link --------------------------------------------------------------------------------

class Link:
    TAP_S = 0.25          # a press shorter than this is a tap, not push-to-talk
    STALE_S = 4.0         # no frame from the node for this long: reconnect (as the console)
    MOD_TIMEOUT_S = 30.0  # no request from the mod for this long: shut down

    def __init__(self, args):
        self.args = args
        self.scale = max(0.0, min(1.0, args.brightness))
        self.mode = "idle"
        self.effect = None             # (mode, until) shown over the mode for a moment
        self.serial = None
        self.connected = False
        self.port = None
        self.status = {}
        self.sequence = 0
        self.write_lock = threading.Lock()
        self.last_frame = 0.0
        self.last_mod = time.monotonic()
        self.pressed_at = None
        self.talk = None
        self.transcribing = False
        self.borrowed = False          # we stopped the console service and must restart it
        self.held_reported = None
        self.takeover_requested = args.handoff == "auto"
        self.simulated = False
        self.stop = threading.Event()
        self.jobs = queue.Queue()
        self.speech = Speech(args.vosk_model, args.refine_model)
        self.announced = False
        self.releasing = False
        self.last_sensor_emit = 0.0

    # -- node I/O --

    def send(self, kind, payload=b""):
        with self.write_lock:
            link = self.serial
            if link is None and not self.simulated:
                return False
            seq = self.sequence
            self.sequence = (seq + 1) & 0xFFFF
            if self.simulated:
                return True
            try:
                link.write(encode(kind, payload, seq))
                return True
            except Exception as exc:
                emit("log", message=f"write failed: {exc}")
                return False

    def mic(self, on):
        self.send(MIC, b"\x01" if on else b"\x00")

    def candidates(self):
        if self.args.port:
            return [p for p in self.args.port.split(",") if p and os.path.exists(p)]
        try:
            from serial.tools import list_ports
        except ImportError:
            return []
        found = []
        for info in list_ports.comports():
            if (info.vid, info.pid) in NODE_IDS:
                found.append(info.device)
        # the CH343 COM port first: the native port re-enumerated badly on Sam's board
        found.sort(key=lambda d: 0 if "1a86" in d.lower() or "ttyUSB" in d or "Single_Serial" in d else 1)
        return found

    def console_active(self):
        if not self.args.console_service or sys.platform != "linux":
            return False
        try:
            return subprocess.run(["systemctl", "--user", "is-active", "--quiet", self.args.console_service],
                                  timeout=5).returncode == 0
        except Exception:
            return False

    def take_over(self):
        """Borrow the node from the Vesper console: stop its service; restart it when done."""
        if self.console_active():
            subprocess.run(["systemctl", "--user", "stop", self.args.console_service], timeout=20)
            self.borrowed = True
            emit("console", state="stopped", service=self.args.console_service)
            time.sleep(1.0)

    def give_back(self):
        if self.borrowed:
            self.borrowed = False
            with contextlib.suppress(Exception):
                subprocess.run(["systemctl", "--user", "start", self.args.console_service], timeout=20)
            emit("console", state="started", service=self.args.console_service)

    def serial_loop(self):
        while not self.stop.is_set():
            if self.simulated:
                time.sleep(0.5)
                continue
            ports = self.candidates()
            if not ports:
                self.report_held(None)
                time.sleep(2)
                continue
            if self.releasing:
                time.sleep(0.5)
                continue
            if self.console_active() and not self.borrowed:
                self.report_held(ports[0])
                if self.takeover_requested:
                    self.take_over()
                else:
                    time.sleep(2)
                    continue
            self.report_held(None)
            for port in ports:
                if self.stop.is_set():
                    break
                self.run_port(port)
            time.sleep(2)

    def report_held(self, port):
        if port != self.held_reported:
            self.held_reported = port
            if port:
                emit("held", port=port, service=self.args.console_service)
            else:
                emit("held", port=None)

    def run_port(self, port):
        try:
            import serial
        except ImportError:
            emit("error", error="pyserial is not installed (pip install pyserial)")
            self.stop.wait(30)
            return
        try:
            link = serial.Serial()
            link.port, link.baudrate = port, 921600
            link.timeout, link.write_timeout = 0.1, 0.5
            link.dtr = False
            link.rts = False
            if sys.platform.startswith("linux"):
                link.exclusive = True
            link.open()
        except Exception as exc:
            emit("log", message=f"{port}: {exc}")
            return
        self.serial, self.port = link, port
        decoder = Decoder()
        self.last_frame = time.monotonic()
        self.announced = False
        last_ping = 0.0
        try:
            while not self.stop.is_set():
                now = time.monotonic()
                if now - last_ping >= 1.0:
                    self.send(PING)
                    last_ping = now
                data = link.read(1)
                if data:
                    data += link.read(min(link.in_waiting, 8192))
                for kind, payload in decoder.feed(data):
                    self.last_frame = time.monotonic()
                    if not self.connected:
                        self.connected = True
                        self.mic(False)
                        self.send(CANCEL)
                        self.send(LEDS, bytes(9))
                    self.packet(kind, payload)
                if time.monotonic() - self.last_frame > (self.STALE_S if self.connected else 3.0):
                    break
                if self.releasing:
                    break
        except Exception as exc:
            emit("log", message=f"{port}: {exc}")
        finally:
            was = self.connected
            if was:
                with contextlib.suppress(Exception):
                    self.mic(False)
                    self.send(CANCEL)
                    self.send(LEDS, bytes(9))
            self.connected = False
            self.abort_talk()
            with contextlib.suppress(Exception):
                link.close()
            self.serial = None
            if was:
                emit("node", connected=False, port=port)

    def packet(self, kind, p):
        if kind in (HELLO, STATUS):
            try:
                status = json.loads(p)
            except ValueError:
                return
            first = not self.status or kind == HELLO
            self.status = status if isinstance(status, dict) else {}
            if first or not self.announced:
                self.announced = True
                emit("node", connected=True, port=self.port, firmware=self.status.get("fw"), link=self.status.get("link"))
            # the node must never capture while we are not listening
            if self.status.get("mic") and self.talk is None:
                self.mic(False)
        elif kind == BUTTON and len(p) == 9:
            _at, pressed = struct.unpack("<QB", p)
            self.button(bool(pressed))
        elif kind == SENSOR and len(p) == 16:
            _at, temp, hum = struct.unpack("<Qff", p)
            now = time.monotonic()
            if math.isfinite(temp) and math.isfinite(hum) and now - self.last_sensor_emit > 5:
                self.last_sensor_emit = now
                emit("sensor", temperature=round(temp, 1), humidity=round(hum, 1))
        elif kind == AUDIO and len(p) >= 6:
            self.audio(p[4:])

    # -- push to talk --

    def button(self, pressed):
        now = time.monotonic()
        emit("button", pressed=pressed)
        if pressed:
            self.pressed_at = now
            if self.transcribing:
                return
            if self.speech.state != "ready":
                emit("ptt", state="unavailable", detail=self.speech.detail or "speech is still loading")
                self.flash("error", 0.6)
                return
            self.talk = Talk(self.speech)
            self.mic(True)
            emit("ptt", state="listening")
            return
        held = now - (self.pressed_at or now)
        self.pressed_at = None
        talk, self.talk = self.talk, None
        if talk is None:
            if held < self.TAP_S:
                emit("tap")
            return
        self.mic(False)
        if held < self.TAP_S:
            talk.cancelled = True
            emit("ptt", state="cancelled")
            emit("tap")
            return
        self.transcribing = True
        emit("ptt", state="transcribing")
        self.jobs.put(("finish", talk, None))

    def audio(self, pcm):
        # Recognition runs on the speech thread so a slow recogniser never stalls the serial reads.
        talk = self.talk
        if talk is None:
            return
        self.jobs.put(("audio", talk, pcm))
        if time.monotonic() - talk.started > Talk.MAX_S:
            emit("ptt", state="error", detail=f"held for more than {Talk.MAX_S} s")
            self.button(False)

    def abort_talk(self):
        if self.talk is not None:
            self.talk.cancelled = True
            self.talk = None
            emit("ptt", state="cancelled")

    def speech_worker(self):
        while not self.stop.is_set():
            try:
                kind, talk, pcm = self.jobs.get(timeout=0.5)
            except queue.Empty:
                continue
            if talk.cancelled:
                if kind == "finish":
                    self.transcribing = False
                continue
            if kind == "audio":
                try:
                    partial = talk.feed(pcm)
                except Exception as exc:
                    emit("log", message=f"recogniser: {exc}")
                    continue
                if partial is not None and talk is self.talk:
                    emit("ptt", state="listening", partial=partial, level=round(talk.level, 2))
                continue
            try:
                text, engine = talk.finish()
                if text:
                    emit("ptt", state="done", text=text, engine=engine)
                    self.flash("ack", 0.35)
                else:
                    emit("ptt", state="empty")
                    self.flash("error", 0.45)
            except Exception as exc:
                emit("ptt", state="error", detail=str(exc))
                self.flash("error", 0.6)
            finally:
                self.transcribing = False

    # -- lamps --

    def flash(self, mode, seconds):
        self.effect = (mode, time.monotonic() + seconds)

    def current_mode(self):
        if self.talk is not None:
            return "listening"
        if self.transcribing:
            return "transcribing"
        effect = self.effect
        if effect and time.monotonic() < effect[1]:
            return effect[0]
        return self.mode

    def lamp_loop(self):
        last = None
        last_sent = 0.0
        t0 = time.monotonic()
        while not self.stop.is_set():
            now = time.monotonic()
            if self.connected or self.simulated:
                level = self.talk.level if self.talk else 0.0
                frame = lamp_frame(self.current_mode(), now - t0, level, self.scale)
                # LEDS cancels a running pattern; resend now and then in case the node reset.
                if frame != last or now - last_sent > 2:
                    if self.send(LEDS, bytes(frame)):
                        last, last_sent = frame, now
                        if self.simulated:
                            emit("lamps", values=frame)
            else:
                last = None
            if not self.args.standalone and now - self.last_mod > self.MOD_TIMEOUT_S:
                emit("log", message="the mod stopped talking; shutting down")
                self.stop.set()
            self.stop.wait(0.05 if not self.simulated else 0.5)

    # -- requests from the mod --

    def request(self, path, body):
        self.last_mod = time.monotonic()
        if path == "/alive":
            return {"ok": True, "connected": self.connected or self.simulated}
        if path == "/mode":
            mode = body.get("mode")
            if mode not in ("off", "idle", "working", "tool", "waiting", "attention"):
                return {"ok": False, "error": "unknown mode"}
            self.mode = mode
            return {"ok": True}
        if path == "/flash":
            mode = body.get("mode")
            if mode not in ("ack", "error", "tool"):
                return {"ok": False, "error": "unknown flash"}
            self.flash(mode, float(body.get("seconds", 0.4)))
            return {"ok": True}
        if path == "/brightness":
            self.scale = max(0.0, min(1.0, float(body.get("level", self.scale))))
            return {"ok": True}
        if path == "/takeover":
            self.takeover_requested = True
            return {"ok": True}
        if path == "/release":
            self.takeover_requested = self.args.handoff == "auto"
            if self.borrowed:
                self.release_port()
            return {"ok": True}
        if path == "/state":
            return {"ok": True, "connected": self.connected or self.simulated, "port": self.port, "status": self.status,
                    "mode": self.current_mode(), "speech": self.speech.state, "borrowed": self.borrowed}
        if path == "/simulate":
            return self.simulate(body)
        return {"ok": False, "error": "unknown request"}

    def release_port(self):
        """Hand the node back to the console now."""
        self.takeover_requested = False
        self.releasing = True
        try:
            deadline = time.monotonic() + 3
            while self.serial is not None and time.monotonic() < deadline:
                time.sleep(0.1)
            self.give_back()
            time.sleep(2)  # let the console open the port before we look again
        finally:
            self.releasing = False

    def simulate(self, body):
        """Testing without a node: connect, press, say. Never used with a real node attached."""
        if self.connected:
            return {"ok": False, "error": "a real node is connected"}
        if "connected" in body:
            self.simulated = bool(body["connected"])
            emit("node", connected=self.simulated, port="simulated", firmware="simulated", link="simulated")
        if "say" in body and self.simulated:
            text = str(body["say"])[:2000]
            emit("button", pressed=True)
            emit("ptt", state="listening")
            emit("ptt", state="transcribing")
            emit("button", pressed=False)
            emit("ptt", state="done", text=text, engine="simulated")
        if body.get("tap") and self.simulated:
            emit("button", pressed=True)
            emit("button", pressed=False)
            emit("tap")
        return {"ok": True}

    # -- life --

    def shutdown(self):
        self.stop.set()
        if self.serial is not None:
            with contextlib.suppress(Exception):
                self.mic(False)
                self.send(CANCEL)
                self.send(LEDS, bytes(9))
                self.serial.close()
        self.give_back()


def serve_http(link, host, port, token):
    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            if self.headers.get("X-Link-Token") != token:
                return self.answer(403, {"ok": False, "error": "bad token"})
            if self.headers.get("Origin"):  # never from a browser page
                return self.answer(403, {"ok": False, "error": "no browsers"})
            try:
                length = min(int(self.headers.get("Content-Length") or 0), 65536)
                body = json.loads(self.rfile.read(length) or b"{}")
                if not isinstance(body, dict):
                    raise ValueError
            except ValueError:
                return self.answer(400, {"ok": False, "error": "bad json"})
            self.answer(200, link.request(self.path, body))

        def answer(self, code, data):
            raw = json.dumps(data).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer((host, port), Handler)
    server.daemon_threads = True
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server


def die_with_parent():
    if sys.platform.startswith("linux"):
        with contextlib.suppress(Exception):
            import ctypes
            ctypes.CDLL("libc.so.6", use_errno=True).prctl(1, signal.SIGTERM)  # PR_SET_PDEATHSIG


def load_config():
    """Settings the installer wrote: config.json in the install folder (the venv's parent), or
    the file VESPER_LINK_CONFIG names. Command-line arguments win over it."""
    path = os.environ.get("VESPER_LINK_CONFIG") or str(Path(sys.prefix).parent / "config.json")
    try:
        data = json.loads(Path(path).read_text())
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def main(argv=None):
    config = load_config()
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--http-port", type=int, default=int(config.get("http_port", 47219)))
    parser.add_argument("--port", default=config.get("serial_port", ""),
                        help="node serial device(s), comma separated; default: find it by USB id")
    parser.add_argument("--vosk-model", default=config.get("vosk_model", ""))
    parser.add_argument("--refine-model", default=config.get("refine_model", ""))
    parser.add_argument("--console-service", default=config.get("console_service", "vesper.service"),
                        help="systemd --user unit of the Vesper console that normally holds the node ('' for none)")
    parser.add_argument("--handoff", choices=("ask", "auto", "never"), default=config.get("handoff", "ask"))
    parser.add_argument("--brightness", type=float, default=float(config.get("brightness", 0.5)))
    parser.add_argument("--standalone", action="store_true",
                        help="testing by hand: keep running without the mod's keep-alive")
    args = parser.parse_args(argv)
    token = os.environ.get("VESPER_LINK_TOKEN", "")
    if not token:
        print("VESPER_LINK_TOKEN must be set", file=sys.stderr)
        return 2
    die_with_parent()
    link = Link(args)
    try:
        serve_http(link, "127.0.0.1", args.http_port, token)
    except OSError as exc:
        emit("error", error=f"cannot listen on 127.0.0.1:{args.http_port}: {exc}")
        return 1
    signal.signal(signal.SIGTERM, lambda *_: link.stop.set())
    signal.signal(signal.SIGINT, lambda *_: link.stop.set())
    emit("hello", version=VERSION, pid=os.getpid())
    for target in (link.serial_loop, link.lamp_loop, link.speech_worker):
        threading.Thread(target=target, daemon=True).start()
    try:
        while not link.stop.wait(0.5):
            pass
    finally:
        link.shutdown()
        emit("bye")
    return 0


def run():
    sys.exit(main())


if __name__ == "__main__":
    run()
