#!/usr/bin/env bash
# Install the VESPER-9 Claude link: the node bridge (a small Python program in its own venv) and
# the vesper-link Claude Code mod. Linux (Raspberry Pi OS included) and macOS. Re-running it
# updates in place and keeps config.json.
#
#   bash install.sh [--vesper-dir PATH] [--no-speech] [--handoff ask|auto|never]
#
# --vesper-dir  the VESPER-9 console checkout; its downloaded speech models are reused and its
#               console service is the one the bridge borrows the node from (Pi only).
# --no-speech   skip Vosk (the lamps and the look still work; push-to-talk says it is unavailable).
set -euo pipefail

here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
share="${XDG_DATA_HOME:-$HOME/.local/share}/vesper-claude-link"
mods="$HOME/.claude/mods"
vesper_dir=""
speech=1
handoff="ask"

while [ $# -gt 0 ]; do
  case "$1" in
    --vesper-dir) vesper_dir="$2"; shift 2 ;;
    --no-speech) speech=0; shift ;;
    --handoff) handoff="$2"; shift 2 ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
done

python="${PYTHON:-python3}"
"$python" -c 'import sys; assert sys.version_info >= (3, 9), "Python 3.9+ needed"'

echo "== bridge: $share"
mkdir -p "$share"
if [ ! -x "$share/venv/bin/python" ]; then
  "$python" -m venv "$share/venv"
fi
"$share/venv/bin/python" -m pip install -q --upgrade pip
extras=""
[ "$speech" = 1 ] && extras="[speech]"
"$share/venv/bin/python" -m pip install -q "$here/bridge$extras"

# Speech models: the console's own if there is a console checkout, otherwise Vosk's small
# English model (about 40 MB) downloaded once into the install folder.
vosk_model=""
refine_model=""
if [ "$speech" = 1 ]; then
  if [ -n "$vesper_dir" ] && [ -d "$vesper_dir/models/vosk-model-small-en-us-0.15/am" ]; then
    vosk_model="$vesper_dir/models/vosk-model-small-en-us-0.15"
    parakeet="$vesper_dir/models/sherpa-onnx-nemo-parakeet_tdt_transducer_110m-en-36000-int8"
    if [ -f "$parakeet/encoder.int8.onnx" ]; then
      refine_model="$parakeet"
      "$share/venv/bin/python" -m pip install -q "$here/bridge[speech,refine]" || refine_model=""
    fi
  else
    vosk_model="$share/models/vosk-model-small-en-us-0.15"
    if [ ! -d "$vosk_model/am" ]; then
      mkdir -p "$share/models"
      tmp="$(mktemp -d)"
      curl -fsSL -o "$tmp/model.zip" https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip
      "$share/venv/bin/python" -m zipfile -e "$tmp/model.zip" "$share/models/"
      rm -rf "$tmp"
    fi
  fi
fi

console_service=""
if [ "$(uname -s)" = Linux ] && systemctl --user cat vesper.service >/dev/null 2>&1; then
  console_service="vesper.service"
fi

# config.json: written once; later runs only fill in what is missing.
"$share/venv/bin/python" - "$share/config.json" "$vosk_model" "$refine_model" "$console_service" "$handoff" <<'PY'
import json, sys
from pathlib import Path
path, vosk, refine, service, handoff = sys.argv[1:]
config = json.loads(Path(path).read_text()) if Path(path).exists() else {}
defaults = {"vosk_model": vosk, "refine_model": refine, "console_service": service,
            "handoff": handoff, "brightness": 0.5, "http_port": 47219, "serial_port": ""}
for key, value in defaults.items():
    if not config.get(key) and value not in ("", None):
        config[key] = value
    config.setdefault(key, value)
Path(path).write_text(json.dumps(config, indent=2) + "\n")
print(json.dumps(config, indent=2))
PY

echo "== mod: $mods/vesper-link"
mkdir -p "$mods"
rm -rf "$mods/vesper-link"
cp -R "$here/mod/vesper-link" "$mods/vesper-link"

# Load the mod in every Claude Code session: CLAUDE_CODE_PLUGIN_DIRS in ~/.claude/settings.json.
"$share/venv/bin/python" - "$HOME/.claude/settings.json" "$mods/vesper-link" <<'PY'
import json, os, sys
from pathlib import Path
path, mod = Path(sys.argv[1]), sys.argv[2]
settings = json.loads(path.read_text()) if path.exists() else {}
env = settings.setdefault("env", {})
dirs = [d for d in env.get("CLAUDE_CODE_PLUGIN_DIRS", "").split(os.pathsep) if d]
if mod not in dirs:
    dirs.append(mod)
env["CLAUDE_CODE_PLUGIN_DIRS"] = os.pathsep.join(dirs)
path.parent.mkdir(parents=True, exist_ok=True)
if path.exists():
    path.with_suffix(".json.bak-vesper-link").write_text(path.read_text())
path.write_text(json.dumps(settings, indent=2) + "\n")
print("CLAUDE_CODE_PLUGIN_DIRS =", env["CLAUDE_CODE_PLUGIN_DIRS"])
PY

if [ "$(uname -s)" = Linux ] && ! id -nG | grep -qw dialout; then
  echo "NOTE: $(id -un) is not in the dialout group, so the bridge may not open the node's port:"
  echo "      sudo usermod -aG dialout $(id -un)   (then log out and in)"
fi

echo
echo "Installed. Check it:  claude plugin validate $mods/vesper-link"
echo "Then start claude, plug in the node, and look for the VESPER-9 band above the prompt."
