// VESPER-9 Claude link: while the Vesper node is plugged in, Claude Code takes on the field
// console's look, the node's three lamps show what Claude is doing, and holding the node's
// button is push-to-talk. The node is reached through a small bridge program (bridge/
// vesper_link.py) that this mod starts and keeps running; it is not the Vesper console and
// does not talk to it, beyond borrowing the node from the console's service when asked.
import { atom, read, update } from 'claude-code'
import type { EngineInterface, Register } from 'claude-code'

import type { VesperLinkAir, VesperLinkLamp, VesperLinkStatus, VesperLinkTalk } from '../types'

const PLUGIN = 'vesper-link'
const PANE = 'vesper-console'

// The console's palette (docs/DESIGN.md in the vesper9 repo).
const C = {
  screen: '#0c1411',
  line: '#39493b',
  text: '#d9e5c9',
  quiet: '#94a58d',
  phosphor: '#d6efa4',
  amber: '#e7b879',
  cyan: '#8fcbc5',
  red: '#eb947a',
  blue: '#7f9cff',
}

const STATUS0: VesperLinkStatus = {
  bridge: 'starting', node: 'absent', port: null, firmware: null,
  speech: 'loading', speechDetail: null, console: null, error: null,
}
const TALK0: VesperLinkTalk = { state: 'idle', partial: '', level: 0, detail: null }

const status = atom({ plugin: 'vesper-link', key: 'status' } as const, STATUS0)
const lamp = atom({ plugin: 'vesper-link', key: 'lamp' } as const, 'idle' as VesperLinkLamp)
const talk = atom({ plugin: 'vesper-link', key: 'talk' } as const, TALK0)
const air = atom({ plugin: 'vesper-link', key: 'air' } as const, null as VesperLinkAir | null)
const voiced = atom({ plugin: 'vesper-link', key: 'voiced' } as const, [] as string[])
const lastHeard = atom({ plugin: 'vesper-link', key: 'lastHeard' } as const, '')

// What each lamp mode is called on screen, and how its three lamps are drawn.
const LAMP_LABEL: Record<VesperLinkLamp, string> = {
  off: 'LINK IDLE',
  idle: 'STANDING BY',
  working: 'CLAUDE AT WORK',
  tool: 'FIELD OPERATION',
  waiting: 'AWAITING OPERATOR',
  attention: 'DECISION REQUIRED',
}
const LAMP_COLORS: Record<VesperLinkLamp, [string, string, string]> = {
  off: [C.line, C.line, C.line],
  idle: [C.line, C.phosphor, C.line],
  working: [C.phosphor, C.phosphor, C.phosphor],
  tool: [C.phosphor, C.phosphor, C.cyan],
  waiting: [C.amber, C.amber, C.amber],
  attention: [C.amber, C.red, C.amber],
}
const SPINNER_WORDS: Record<string, string> = {
  requesting: 'Hailing',
  thinking: 'Calculating orbit',
  responding: 'Receiving transmission',
  'tool-input': 'Plotting operation',
  'tool-use': 'Field operation',
}

type Options = {
  bridgeCommand: string
  httpPort: number
  style: 'auto' | 'always' | 'never'
  voiceSend: 'send' | 'draft'
  doubleTapInterrupt: boolean
  brightness: number
}

const meter = (level: number, width = 8) => {
  const lit = Math.round(Math.max(0, Math.min(1, level)) * width)
  return '▮'.repeat(lit) + '▯'.repeat(width - lit)
}
const clip = (text: string, room: number) =>
  text.length <= room ? text : '…' + text.slice(text.length - Math.max(1, room - 1))

// What the module keeps between hooks; a reload starts it over (the bridge is restarted too).
type Link = {
  options: Options
  token: string
  base: string
  lampSent: VesperLinkLamp | null
  turnId: string | null
  lastTapAt: number
  idleTimer: { cancel: () => void } | null
  stopped: boolean
}
let L: Link

// ---- the bridge ---------------------------------------------------------------------------

async function post($: EngineInterface, path: string, body: object = {}) {
  try {
    const res = await $.http.fetch(L.base + path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Link-Token': L.token },
      body: JSON.stringify(body),
    })
    return res.ok ? (JSON.parse(res.text) as Record<string, unknown>) : null
  } catch {
    return null
  }
}

async function setLamp($: EngineInterface, mode: VesperLinkLamp) {
  L.idleTimer?.cancel()
  L.idleTimer = null
  await update($, lamp, () => mode)
  if (mode === 'waiting') {
    // nobody has answered for ten minutes: drop to the dim standby breath
    L.idleTimer = $.clock.after(10 * 60 * 1000, () => void setLamp($, 'idle'))
  }
  if (L.lampSent !== mode) {
    L.lampSent = mode
    await post($, '/mode', { mode })
  }
}

async function isActive($: EngineInterface) {
  if (L.options.style === 'never') return false
  if (L.options.style === 'always') return true
  return (await read($, status)).node === 'connected'
}

async function handle($: EngineInterface, msg: Record<string, unknown>) {
  switch (msg.type) {
    case 'hello':
      await update($, status, (s): VesperLinkStatus => ({ ...s, bridge: 'running', error: null }))
      await post($, '/brightness', { level: Math.max(0, Math.min(100, L.options.brightness ?? 50)) / 100 })
      L.lampSent = null
      await setLamp($, await read($, lamp))
      return
    case 'node': {
      const connected = msg.connected === true
      await update($, status, (s): VesperLinkStatus => ({
        ...s,
        node: connected ? 'connected' : 'absent',
        port: connected ? String(msg.port ?? '') : null,
        firmware: connected ? String(msg.firmware ?? '') : null,
      }))
      if (connected) {
        $.ui.toast('VESPER-9 node linked. Hold the button to talk.')
        L.lampSent = null
        await setLamp($, L.turnId ? 'working' : 'waiting')
      } else {
        $.ui.toast('VESPER-9 node unplugged.')
        await update($, talk, () => TALK0)
      }
      return
    }
    case 'held':
      await update($, status, (s): VesperLinkStatus =>
        msg.port ? { ...s, node: 'held', port: String(msg.port) } : s.node === 'held' ? { ...s, node: 'absent', port: null } : s,
      )
      if (msg.port) $.ui.toast('VESPER-9 node found, but the Vesper console is using it. /vesper takeover borrows it.')
      return
    case 'console':
      await update($, status, (s): VesperLinkStatus => ({ ...s, console: msg.state === 'stopped' ? 'borrowed' : null }))
      return
    case 'speech':
      await update($, status, (s): VesperLinkStatus => ({
        ...s,
        speech: msg.state === 'ready' ? String(msg.engine ?? 'ready') : String(msg.state),
        speechDetail: typeof msg.detail === 'string' ? msg.detail : null,
      }))
      return
    case 'sensor':
      await update($, air, () => ({ temperature: Number(msg.temperature), humidity: Number(msg.humidity) }))
      return
    case 'ptt':
      return onTalk($, msg)
    case 'tap':
      return onTap($)
    case 'error':
      await update($, status, (s): VesperLinkStatus => ({ ...s, error: String(msg.error ?? 'bridge error') }))
      return
    default:
      return
  }
}

async function onTalk($: EngineInterface, msg: Record<string, unknown>) {
  const state = String(msg.state) as VesperLinkTalk['state']
  const detail = typeof msg.detail === 'string' ? msg.detail : null
  if (state === 'listening') {
    await update($, talk, t => ({
      state,
      partial: typeof msg.partial === 'string' ? msg.partial : t.state === 'listening' ? t.partial : '',
      level: typeof msg.level === 'number' ? msg.level : t.level,
      detail: null,
    }))
    return
  }
  if (state === 'done') {
    const text = String(msg.text ?? '').trim()
    await update($, talk, () => ({ ...TALK0, state: 'done', partial: text }))
    await update($, lastHeard, () => text)
    if (!text) return
    if (L.options.voiceSend === 'draft') {
      await $.prompt.fill({ text, mode: 'append' })
    } else {
      await update($, voiced, list => [...list, text].slice(-50))
      void $.prompt.submit({ text, asUser: true })
    }
    return
  }
  if (state === 'unavailable') $.ui.toast(`Push-to-talk is unavailable: ${detail ?? 'no speech model'}`)
  if (state === 'empty') $.ui.toast('Nothing was heard. Hold the button and speak.')
  if (state === 'error') $.ui.toast(`Push-to-talk failed: ${detail ?? 'unknown error'}`)
  await update($, talk, () => ({ ...TALK0, state, detail }))
}

async function onTap($: EngineInterface) {
  const now = await $.clock.now()
  const isDouble = now - L.lastTapAt < 600
  L.lastTapAt = isDouble ? 0 : now
  if (isDouble && L.options.doubleTapInterrupt && L.turnId) {
    const id = L.turnId
    try {
      await $.turn.abort({ turnId: id })
      $.ui.toast('Transmission halted.')
      await post($, '/flash', { mode: 'error', seconds: 0.3 })
    } catch {
      // the turn had already ended
    }
  }
}

async function runBridge($: EngineInterface) {
  const home = (await $.env.get('HOME')) ?? ''
  const command = L.options.bridgeCommand || `${home}/.local/share/vesper-claude-link/venv/bin/vesper-link`
  let delay = 5000
  while (!L.stopped) {
    await update($, status, (s): VesperLinkStatus => ({ ...s, bridge: 'starting' }))
    const startedAt = await $.clock.now()
    let buffer = ''
    try {
      const child = $.process.spawn({
        argv: [command, '--http-port', String(L.options.httpPort || 47219)],
        env: { VESPER_LINK_TOKEN: L.token },
      })
      for await (const piece of child) {
        if (piece.stream === 'stderr') {
          $.ui.log(piece.text.trimEnd(), { to: 'debug' })
          continue
        }
        buffer += piece.text
        let nl = buffer.indexOf('\n')
        while (nl >= 0) {
          const line = buffer.slice(0, nl).trim()
          buffer = buffer.slice(nl + 1)
          nl = buffer.indexOf('\n')
          if (!line.startsWith('{')) continue
          try {
            await handle($, JSON.parse(line) as Record<string, unknown>)
          } catch (err) {
            $.ui.log(`vesper-link: ${String(err)}`, { to: 'debug' })
          }
        }
      }
      await update($, status, (s): VesperLinkStatus => ({ ...s, bridge: 'down', node: 'absent' }))
    } catch (err) {
      await update($, status, (s): VesperLinkStatus => ({ ...s, bridge: 'down', node: 'absent', error: `bridge did not start: ${command}` }))
      $.ui.log(`vesper-link: ${String(err)}`, { to: 'debug' })
    }
    L.lampSent = null
    // a bridge that ran for a while is restarted quickly; one that keeps failing, slowly
    delay = (await $.clock.now()) - startedAt > 60_000 ? 5000 : Math.min(delay * 2, 120_000)
    await $.clock.sleep(delay)
  }
}

export const register: Register = (on, rawOptions) => {
  const options = rawOptions as unknown as Options
  L = {
    options,
    token: crypto.randomUUID(),
    base: `http://127.0.0.1:${options.httpPort || 47219}`,
    lampSent: null,
    turnId: null,
    lastTapAt: 0,
    idleTimer: null,
    stopped: false,
  }

  // ---- session life -------------------------------------------------------------------------

  on('session.start', async ($, e, next) => {
    const started = await next(e)
    await $.command.register({
      name: 'vesper',
      description: 'VESPER-9 link: open the console pane, or takeover | release | lamps <0-100> | simulate | say <text>',
    })
    // ends only when the session or this module does; a failure past that point has no one to tell
    void runBridge($).catch(() => undefined)
    $.clock.every(5000, () => void post($, '/alive'))
    return started
  })

  on('session.end', async ($, e, next) => {
    L.stopped = true
    await post($, '/mode', { mode: 'off' })
    return next(e)
  })

  // ---- what Claude is doing, on the lamps ---------------------------------------------------

  on('turn.start', async ($, e, next) => {
    const started = await next(e)
    L.turnId = started.turnId
    await setLamp($, 'working')
    return started
  })

  on('tool.call', async ($, e, next) => {
    if (L.turnId) await post($, '/flash', { mode: 'tool', seconds: 0.6 })
    return next(e)
  })

  on('classic.PermissionRequest', async ($, e, next) => {
    await setLamp($, 'attention')
    return next(e)
  })

  on('classic.PostToolUse', async ($, e, next) => {
    if ((await read($, lamp)) === 'attention') await setLamp($, 'working')
    return next(e)
  })

  on('classic.Notification', async ($, e, next) => {
    if (e.notification_type.includes('permission')) await setLamp($, 'attention')
    return next(e)
  })

  on('turn.complete', async ($, e, next) => {
    if (e.agentId === undefined) {
      L.turnId = null
      await setLamp($, 'waiting')
      if (e.reason === 'error') await post($, '/flash', { mode: 'error', seconds: 0.6 })
    }
    return next(e)
  })

  // ---- /vesper -------------------------------------------------------------------------------

  on('command.run', { command: 'vesper' }, async ($, e) => {
    const [verb = '', ...rest] = e.args.trim().split(/\s+/)
    switch (verb.toLowerCase()) {
      case '':
        await $.ui.open({ id: PANE, title: 'VESPER-9', focus: true, closeOnEscape: true })
        return { text: 'VESPER-9 console opened.' }
      case 'takeover':
        await post($, '/takeover')
        return { text: 'Borrowing the node from the Vesper console. Its service is L.stopped until /vesper release or the end of this session.' }
      case 'release':
        await post($, '/release')
        return { text: 'Node handed back to the Vesper console.' }
      case 'lamps': {
        const level = Math.max(0, Math.min(100, Number(rest[0])))
        if (!Number.isFinite(level)) return { text: 'Usage: /vesper lamps <0-100>' }
        await post($, '/brightness', { level: level / 100 })
        return { text: `Lamp brightness ${level}.` }
      }
      case 'simulate': {
        const answer = await post($, '/simulate', { connected: rest[0] !== 'off' })
        return { text: answer?.ok ? 'Simulated node ' + (rest[0] === 'off' ? 'unplugged.' : 'linked.') : `Simulation refused: ${String(answer?.error ?? 'no bridge')}` }
      }
      case 'say': {
        const answer = await post($, '/simulate', { say: rest.join(' ') })
        return { text: answer?.ok ? 'Simulated push-to-talk sent.' : 'Simulation refused.' }
      }
      default:
        return { text: 'Usage: /vesper [takeover | release | lamps <0-100> | simulate [off] | say <text>]' }
    }
  })

  // ---- the look ------------------------------------------------------------------------------

  // The instrument band above the prompt: lamps, state, live voice.
  on('ui.render', { component: 'AbovePrompt' }, async ($, e, next) => {
    if (e.props.hasSurvey) return next(e)
    const s = await read($, status)
    const active = await isActive($)
    if (!active && s.node !== 'held') return next(e)
    const { Box, Text } = $.ui.resolve(e)
    const t = await read($, talk)
    const mode = await read($, lamp)
    const a = await read($, air)
    const width = Math.max(20, e.props.bodyColumns)
    const airText = a ? `${a.temperature.toFixed(1)}°C · ${Math.round(a.humidity)}% RH` : ''

    let lamps: [string, string, string] = LAMP_COLORS[mode]
    let label = LAMP_LABEL[mode]
    let labelColor = mode === 'attention' ? C.red : mode === 'waiting' ? C.amber : C.phosphor
    let line2: string = mode === 'waiting' || mode === 'idle' ? 'HOLD THE BUTTON TO TRANSMIT' : L.turnId ? 'TAP TWICE TO HALT' : ''
    if (s.node === 'held') {
      lamps = [C.line, C.line, C.line]
      label = 'NODE HELD BY THE CONSOLE'
      labelColor = C.amber
      line2 = '/vesper takeover TO BORROW IT'
    } else if (s.node !== 'connected') {
      lamps = [C.line, C.line, C.line]
      label = s.bridge === 'down' ? 'BRIDGE OFFLINE' : 'NO NODE'
      labelColor = C.quiet
      line2 = s.error ?? 'PLUG IN THE NODE'
    } else if (t.state === 'listening') {
      lamps = [C.amber, t.level > 0.5 ? C.amber : C.line, C.blue]
      label = `TRANSMITTING ${meter(t.level)}`
      labelColor = C.amber
      line2 = t.partial ? `“${clip(t.partial, width - 8)}”` : 'SPEAK NOW · RELEASE TO SEND'
    } else if (t.state === 'transcribing') {
      lamps = [C.cyan, C.cyan, C.cyan]
      label = 'DECODING SIGNAL'
      labelColor = C.cyan
      line2 = ''
    }

    if (e.props.maxRows < 4 || width < 40) {
      return (
        <Box>
          <Text color={lamps[0]}>● </Text>
          <Text color={lamps[1]}>● </Text>
          <Text color={lamps[2]}>● </Text>
          <Text color={labelColor} bold>{label}</Text>
        </Box>
      )
    }
    return (
      <Box flexDirection="column" borderStyle="round" borderColor={C.line} paddingX={1} width={width}>
        <Box justifyContent="space-between">
          <Box>
            <Text color={C.phosphor} bold>VESPER-9</Text>
            <Text color={C.quiet}> ▸ CLAUDE LINK</Text>
          </Box>
          <Text color={C.cyan}>{airText}</Text>
        </Box>
        <Box>
          <Text color={lamps[0]}>● </Text>
          <Text color={lamps[1]}>● </Text>
          <Text color={lamps[2]}>●  </Text>
          <Text color={labelColor} bold>{label}</Text>
        </Box>
        {line2 !== '' && <Text color={t.state === 'listening' ? C.text : C.quiet} wrap="truncate-start">{line2}</Text>}
      </Box>
    )
  })

  // The operator's messages, as console log entries.
  on('ui.render', { component: 'UserMessage' }, async ($, e, next) => {
    if (e.props.isExpanded || !(await isActive($))) return next(e)
    if (e.props.origin.kind !== 'composer' && e.props.origin.kind !== 'unclassified') {
      const said = await read($, voiced)
      if (!said.includes(e.props.text.trim())) return next(e)
    }
    const { Box, Text } = $.ui.resolve(e)
    const said = await read($, voiced)
    const isVoice = said.includes(e.props.text.trim())
    return (
      <Box flexDirection="column" marginTop={1}>
        <Box>
          <Text color={C.amber} bold>▸ OPERATOR</Text>
          <Text color={C.quiet}>{isVoice ? '  · VOICE CH-1' : '  · KEY CH-2'}</Text>
        </Box>
        <Box paddingLeft={2}>
          <Text color={C.text}>{e.props.text}</Text>
        </Box>
      </Box>
    )
  })

  // Claude's replies, as incoming transmissions.
  on('ui.render', { component: 'AssistantMessage' }, async ($, e, next) => {
    if (!(await isActive($))) return next(e)
    const { Box, Text, Markdown } = $.ui.resolve(e)
    return (
      <Box flexDirection="column" marginTop={e.props.isFirstOfReply ? 1 : 0}>
        {e.props.isFirstOfReply && <Text color={C.cyan} bold>◂ CLAUDE · INCOMING</Text>}
        <Box paddingLeft={2}>
          <Markdown text={e.props.text} />
        </Box>
      </Box>
    )
  })

  on('ui.render', { component: 'Spinner' }, async ($, e, next) => {
    if (!(await isActive($))) return next(e)
    return next({ ...e, props: { ...e.props, word: SPINNER_WORDS[e.props.mode] ?? e.props.word } })
  })

  // The console pane: every channel of the link at a glance.
  on('ui.render', { component: 'Pane', requestId: PANE }, async ($, e) => {
    const { Box, Text, Button } = $.ui.resolve(e)
    const s = await read($, status)
    const mode = await read($, lamp)
    const a = await read($, air)
    const heard = await read($, lastHeard)
    const colors = LAMP_COLORS[mode]
    const row = (channel: string, name: string, value: string, color: string) => (
      <Box>
        <Text color={C.quiet}>{channel}  </Text>
        <Text color={C.text}>{name.padEnd(8)}</Text>
        <Text color={color}>{value}</Text>
      </Box>
    )
    const node =
      s.node === 'connected' ? `LINKED  ${s.port ?? ''}  FW ${s.firmware ?? '?'}`
        : s.node === 'held' ? `HELD BY CONSOLE  ${s.port ?? ''}`
          : s.bridge === 'down' ? `BRIDGE OFFLINE  ${s.error ?? ''}` : 'NO NODE'
    const voice = s.speech === 'unavailable' ? `UNAVAILABLE  ${s.speechDetail ?? ''}` : s.speech.toUpperCase()
    return (
      <Box flexDirection="column" paddingX={1}>
        <Text color={C.phosphor} bold>V E S P E R - 9   ·   C L A U D E   L I N K</Text>
        <Text color={C.line}>{'─'.repeat(Math.max(10, Math.min(60, (e.viewport?.columns ?? 60) - 4)))}</Text>
        {row('CH-1', 'NODE', node, s.node === 'connected' ? C.phosphor : C.amber)}
        {row('CH-2', 'VOICE', voice, s.speech === 'unavailable' ? C.red : C.cyan)}
        <Box>
          <Text color={C.quiet}>CH-3  </Text>
          <Text color={C.text}>{'LAMPS'.padEnd(8)}</Text>
          <Text color={colors[0]}>● </Text>
          <Text color={colors[1]}>● </Text>
          <Text color={colors[2]}>●  </Text>
          <Text color={C.quiet}>{LAMP_LABEL[mode]}</Text>
        </Box>
        {row('CH-4', 'AIR', a ? `${a.temperature.toFixed(1)} °C   ${Math.round(a.humidity)} % RH` : 'NO READING', C.cyan)}
        {row('CH-5', 'CONSOLE', s.console === 'borrowed' ? 'SERVICE PAUSED, NODE BORROWED' : 'UNTOUCHED', C.quiet)}
        <Text color={C.line}>{'─'.repeat(Math.max(10, Math.min(60, (e.viewport?.columns ?? 60) - 4)))}</Text>
        <Text color={C.quiet}>LAST TRANSMISSION</Text>
        <Text color={C.text}>{heard ? `“${heard}”` : '—'}</Text>
        <Box marginTop={1} gap={1}>
          {s.node === 'held' && (
            <Button key="takeover" label="Borrow node" hotkey="b" variant="primary" onPress={() => void post($, '/takeover')} />
          )}
          {s.console === 'borrowed' && (
            <Button key="release" label="Give node back" hotkey="g" onPress={() => void post($, '/release')} />
          )}
          <Button key="dim" label="Lamps −" hotkey="d" onPress={() => void post($, '/brightness', { level: 0.2 })} />
          <Button key="bright" label="Lamps +" hotkey="u" onPress={() => void post($, '/brightness', { level: 0.8 })} />
          <Button key="close" label="Close" role="dismiss" onPress={() => void $.ui.close({ id: PANE })} />
        </Box>
      </Box>
    )
  })
}
