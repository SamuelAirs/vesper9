import { expect, mock, test } from 'claude-code/testing'

// A fake bridge: the test answers the mod's process.spawn with the lines a real bridge prints,
// and its http.fetch with ok, recording what the mod asked of the lamps.
const lines = (...messages: object[]) => messages.map(m => JSON.stringify(m)).join('\n') + '\n'

function deferred<T>() {
  let resolve!: (value: T) => void
  const promise = new Promise<T>(r => (resolve = r))
  return { promise, resolve }
}

const OK = { status: 200, ok: true, headers: {}, text: '{"ok":true}' }
// the band's props, less the scroll and view handles the engine adds (unused here)
const BAND = { hasSurvey: false, isWorking: false, maxRows: 6, bodyColumns: 80 } as never

test('the node links, the band appears, and push-to-talk becomes a prompt', async ($, on) => {
  const posts: { path: string; body: Record<string, unknown> }[] = []
  const submitted = deferred<string>()
  const finish = deferred<void>()
  let argv: readonly string[] = []

  on('http.fetch', async (_$, e) => {
    const url = new URL(e.url)
    posts.push({ path: url.pathname, body: JSON.parse(String(e.init?.body ?? '{}')) })
    return { value: OK }
  })
  on('process.spawn', async function* (_$, e) {
    argv = e.argv
    yield { stream: 'stdout' as const, text: lines({ type: 'hello', version: '0.1.0' }, { type: 'speech', state: 'ready', engine: 'vosk' }) }
    yield { stream: 'stdout' as const, text: lines({ type: 'node', connected: true, port: '/dev/ttyUSB0', firmware: '0.1.2' }) }
    // a line split across two pieces, as a pipe may deliver it
    const said = JSON.stringify({ type: 'ptt', state: 'done', text: 'what is the build status', engine: 'vosk' })
    yield { stream: 'stdout' as const, text: said.slice(0, 20) }
    yield { stream: 'stdout' as const, text: said.slice(20) + '\n' }
    await finish.promise
    return { value: { code: 0, signal: null } }
  })
  on('prompt.submit', async (_$, e) => {
    submitted.resolve(e.text)
    return { text: e.text }
  })

  mock.clock(on, { now: 1_000_000 })
  mock.env(on, { HOME: '/home/sam' })
  on('session.start', async (_$, e) => ({ cwd: e.cwd }))
  on('command.register', async (_$, e) => ({ value: { command: e.name } }))
  // stands in for the engine's own drawing, which a plugin reaches with next(e)
  on('ui.render', (async ($e: any, e: any) => h($e.ui.resolve(e).Text, {}, 'engine default')) as never)
  await $.session.start({ cwd: '/tmp', surface: 'terminal', isInteractive: true })
  expect(await submitted.promise).toBe('what is the build status')
  expect(argv[0]).toBe('/home/sam/.local/share/vesper-claude-link/venv/bin/vesper-link')
  expect(posts.some(p => p.path === '/mode' && p.body.mode === 'waiting')).toBe(true)

  for (const surface of ['terminal', 'desktop'] as const) {
    const ui = await $.ui.mount({ plugin: 'vesper-link', surface, component: 'AbovePrompt', props: BAND })
    expect(await ui.find({ type: 'Text', text: 'VESPER-9' })).toBeDefined()
    expect(await ui.find({ type: 'Text', text: /AWAITING OPERATOR/ })).toBeDefined()
    await ui.unmount()
  }
  finish.resolve()
})

test('without a node the prompt area is left alone', async ($, on) => {
  const finish = deferred<void>()
  on('http.fetch', async () => ({ value: OK }))
  on('process.spawn', async function* () {
    yield { stream: 'stdout' as const, text: lines({ type: 'hello', version: '0.1.0' }) }
    await finish.promise
    return { value: { code: 0, signal: null } }
  })
  mock.clock(on, { now: 1_000_000 })
  mock.env(on, { HOME: '/home/sam' })
  on('session.start', async (_$, e) => ({ cwd: e.cwd }))
  on('command.register', async (_$, e) => ({ value: { command: e.name } }))
  // stands in for the engine's own drawing, which a plugin reaches with next(e)
  on('ui.render', (async ($e: any, e: any) => h($e.ui.resolve(e).Text, {}, 'engine default')) as never)
  await $.session.start({ cwd: '/tmp', surface: 'terminal', isInteractive: true })
  const ui = await $.ui.mount({ plugin: 'vesper-link', surface: 'terminal', component: 'AbovePrompt', props: BAND })
  expect(await ui.find({ type: 'Text', text: 'VESPER-9' })).toBeUndefined()
  await ui.unmount()
  finish.resolve()
})
