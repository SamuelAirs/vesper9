export type VesperLinkNode = 'absent' | 'held' | 'connected'
export type VesperLinkBridge = 'starting' | 'running' | 'down'
export type VesperLinkLamp = 'off' | 'idle' | 'working' | 'tool' | 'waiting' | 'attention'

export type VesperLinkStatus = {
  bridge: VesperLinkBridge
  node: VesperLinkNode
  port: string | null
  firmware: string | null
  speech: string
  speechDetail: string | null
  console: string | null
  error: string | null
}

export type VesperLinkTalk = {
  state: 'idle' | 'listening' | 'transcribing' | 'done' | 'empty' | 'error' | 'unavailable' | 'cancelled'
  partial: string
  level: number
  detail: string | null
}

export type VesperLinkAir = { temperature: number; humidity: number }

declare module 'claude-code' {
  interface PluginState {
    'vesper-link': {
      status: VesperLinkStatus
      lamp: VesperLinkLamp
      talk: VesperLinkTalk
      air: VesperLinkAir | null
      voiced: string[]
      lastHeard: string
    }
  }
}
